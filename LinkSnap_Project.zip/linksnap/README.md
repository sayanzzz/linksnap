# LinkSnap : URL Shortener with Analytics

A full-stack URL shortening service supporting custom short code generation, seamless redirect handling, and per-link analytics (click tracking). 

## Tech Stack
* **Backend:** Java, Spring Boot, Spring Data JPA, REST APIs
* **Frontend:** React, Axios, CSS
* **Database:** MySQL
* **Encoding:** Base62 (Collision-safe shortcode generation)

## Setup Instructions

### 1. Database (MySQL)
Create a database named `linksnap`:
```sql
CREATE DATABASE linksnap;
```

### 2. Backend Setup
1. Navigate to the `backend` directory.
2. Update `src/main/resources/application.properties` with your MySQL credentials.
3. Run the application using Maven:
   ```bash
   ./mvnw spring-boot:run
   ```

### 3. Frontend Setup
1. Navigate to the `frontend` directory.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```
