package com.linksnap.controller;

import com.linksnap.model.Url;
import com.linksnap.repository.UrlRepository;
import com.linksnap.util.Base62Encoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "*") 
public class UrlController {

    @Autowired
    private UrlRepository urlRepository;

    @PostMapping("/api/url/shorten")
    public ResponseEntity<Url> shortenUrl(@RequestBody String originalUrl) {
        Url url = new Url();
        url.setOriginalUrl(originalUrl);
        url = urlRepository.save(url); 
        
        url.setShortCode(Base62Encoder.encode(url.getId() + 10000));
        urlRepository.save(url);
        
        return ResponseEntity.ok(url);
    }

    @GetMapping("/{shortCode}")
    public ResponseEntity<Void> redirect(@PathVariable String shortCode) {
        Optional<Url> urlOpt = urlRepository.findByShortCode(shortCode);
        if (urlOpt.isPresent()) {
            Url url = urlOpt.get();
            url.setClickCount(url.getClickCount() + 1);
            urlRepository.save(url);
            return ResponseEntity.status(HttpStatus.FOUND)
                    .location(URI.create(url.getOriginalUrl())).build();
        }
        return ResponseEntity.notFound().build();
    }
    
    @GetMapping("/api/url/stats/{shortCode}")
    public ResponseEntity<Url> getStats(@PathVariable String shortCode) {
        return urlRepository.findByShortCode(shortCode)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
