import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [originalUrl, setOriginalUrl] = useState('');
  const [shortUrl, setShortUrl] = useState('');
  const [stats, setStats] = useState(null);

  const handleShorten = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8080/api/url/shorten', originalUrl, {
        headers: { 'Content-Type': 'text/plain' }
      });
      setShortUrl(`http://localhost:8080/${response.data.shortCode}`);
      setStats(response.data);
    } catch (error) {
      console.error('Error shortening URL', error);
    }
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>LinkSnap Dashboard</h1>
      <form onSubmit={handleShorten}>
        <input 
          type="url" 
          placeholder="Enter long URL here..." 
          value={originalUrl} 
          onChange={(e) => setOriginalUrl(e.target.value)} 
          required 
          style={{ width: '300px', padding: '8px' }}
        />
        <button type="submit" style={{ padding: '8px 16px', marginLeft: '8px' }}>Shorten</button>
      </form>

      {shortUrl && (
        <div style={{ marginTop: '2rem', padding: '1rem', border: '1px solid #ccc' }}>
          <h3>Success!</h3>
          <p>Short Link: <a href={shortUrl} target="_blank" rel="noreferrer">{shortUrl}</a></p>
          <p>Clicks: {stats.clickCount}</p>
        </div>
      )}
    </div>
  );
}

export default App;
